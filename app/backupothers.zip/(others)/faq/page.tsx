"use client";
import FAQ from "@/components/FAQ/FAQ2";

function Page() {
    return ( <FAQ /> );
}

export default Page;<FAQ />