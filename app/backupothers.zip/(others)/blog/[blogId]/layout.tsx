 

export default function BlogLayout ({children}:any){

    return (
      <>
      {/* <Header /> */}
      {/* <Lines /> */}
      {children}
      {/* <Footer /> */}
          
         </>
    )
  }
  